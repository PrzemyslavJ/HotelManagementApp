﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HotelManagementApp.Models
{
    public class ResultProcess
    {
        public string TextCommunicate { get; set; }

        public bool ResultOfProcess { get; set; }
    }
}